# SDEV140_FinalProject
# 4 Dry Out e-Rental GUI, 10/2/21, version 6 

from breezypythongui import EasyFrame
from tkinter import *


class GUI4DryOut(EasyFrame):
    # initialize window 
    def __init__(self):
        EasyFrame.__init__(self)
        
        # title font 
        Font_tuple = ("Helvetica", 20, "bold")
        # title 
        self.addLabel(text = "4 Dry Out e-Rental", row=0, column=0,
                      sticky="NSEW", background="navy", foreground="#e9ecf2",
                                                    font=Font_tuple)
        # background color 
        self["background"] = "navy"
        # buttons for equipment options 
        self.Btn = self.addButton(text = "Air Movers/Fans", row=2, column=0,
                                                    command=Open)
        self.Btn = self.addButton(text = "Dehumifiers", row=3, column=0,
                                                    command=Open)
        self.Btn = self.addButton(text = "Air Filtration", row=4, column=0,
                                                    command=Open)
        self.Btn = self.addButton(text = "Extractors/Cleaners", row=1, column=0,
                                                    command=Open)
        self.Btn = self.addButton(text = "Generators", row=5, column=0,
                                                    command=Open)
# open new window 
def Open():
    NewWin = Tk()
    lbl = Label(NewWin, text = "Water Damage Equipment")
    NewWin["bg"] = "navy"
    NewWin.mainloop()

def main():
    
    GUI4DryOut().mainloop()
                                  
    
if __name__ == "__main__":
    main() 

